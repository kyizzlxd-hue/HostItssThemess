import tw from 'twin.macro';
import { createGlobalStyle } from 'styled-components/macro';

export default createGlobalStyle`
    body {
        ${tw`font-sans`};
        color:var(--color);
        background-color:var(--background-color) !important;
        letter-spacing: 0.015em;
    }

    h1, h2, h3, h4, h5, h6 {
        ${tw`font-medium tracking-normal font-header`};
    }

    p {
        ${tw`leading-snug font-sans`};
        color:var(--color);
    }

    form {
        ${tw`m-0`};
    }

    textarea, select, input, button, button:focus, button:focus-visible {
        ${tw`outline-none`};
    }

    input[type=number]::-webkit-outer-spin-button,
    input[type=number]::-webkit-inner-spin-button {
        -webkit-appearance: none !important;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield !important;
    }

    /* Scroll Bar Style */
    ::-webkit-scrollbar {
        background: none;
        width: 16px;
        height: 16px;
    }

    ::-webkit-scrollbar-thumb {
        border: solid 0 rgb(0 0 0 / 0%);
        border-right-width: 4px;
        border-left-width: 4px;
        -webkit-border-radius: 9px 4px;
        -webkit-box-shadow: inset 0 0 0 1px hsl(211, 10%, 53%), inset 0 0 0 4px hsl(209deg 18% 30%);
    }

    ::-webkit-scrollbar-track-piece {
        margin: 4px 0;
    }

    ::-webkit-scrollbar-thumb:horizontal {
        border-right-width: 0;
        border-left-width: 0;
        border-top-width: 4px;
        border-bottom-width: 4px;
        -webkit-border-radius: 4px 9px;
    }

    ::-webkit-scrollbar-thumb:hover {
        -webkit-box-shadow:
        inset 0 0 0 1px var(--primary),
        inset 0 0 0 4px var(--primary);
    }

    ::-webkit-scrollbar-corner {
        background: transparent;
    }


    /* ItsHost Stellar palette: white surfaces, orange borders, blue accents, black text */
    :root {
        --itshost-blue: #087bff;
        --itshost-orange: #ff7900;
        --itshost-black: #111111;
        --itshost-white: #ffffff;
    }
    body {
        color: var(--itshost-black) !important;
        background: var(--itshost-white) !important;
    }
    body, body p, body label, body h1, body h2, body h3, body h4, body h5, body h6,
    body span, body a, body small {
        color: var(--itshost-black);
    }
    input, textarea, select {
        color: var(--itshost-black) !important;
        background: #ffffff !important;
        border: 2px solid var(--itshost-blue) !important;
        border-radius: 7px !important;
        box-shadow: none !important;
    }
    input:focus, textarea:focus, select:focus {
        border-color: var(--itshost-orange) !important;
        box-shadow: 0 0 0 2px rgba(255, 121, 0, .14) !important;
    }
    button, [role="button"] {
        border-radius: 7px;
    }
    a:hover { color: var(--itshost-blue); }
    /* Login card rendered by Stellar */
    form .box {
        background: #ffffff !important;
        color: #111111 !important;
        border: 2px solid var(--itshost-orange) !important;
        border-radius: 10px !important;
        box-shadow: 5px 5px 0 #111111 !important;
    }
    form .box h2, form .box label, form .box p, form .box a {
        color: #111111 !important;
    }
    form .box button[type="submit"] {
        color: #ffffff !important;
        background: var(--itshost-blue) !important;
        border: 2px solid var(--itshost-orange) !important;
        box-shadow: 3px 3px 0 #111111 !important;
    }
    form .box button[type="submit"]:hover {
        background: #0068df !important;
    }
`;
